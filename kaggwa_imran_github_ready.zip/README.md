# Kaggwa Imran — Digital Tools & AI Resources

A responsive, static two-page website for showcasing digital products and a KDP book catalogue.

## Pages

- `index.html` — homepage, product cards, product finder, FAQ, and contact details.
- `kdp-books.html` — KDP book catalogue with search and links to Amazon listings.

## Contact

- WhatsApp: [+256784324301](https://wa.me/256784324301)
- Email: [kaggwaimrankevin@gmail.com](mailto:kaggwaimrankevin@gmail.com)

## Run locally

No build tools or package installation are required.

1. Download or clone this repository.
2. Open `index.html` in a browser.
3. Use the navigation link to open the book catalogue.

For a more realistic local test, serve the files with any static HTTP server.

## Publish with GitHub Pages

1. Create a GitHub repository and upload **all files in this folder** to the repository root.
2. In the repository, open **Settings → Pages**.
3. Under **Build and deployment**, choose **Deploy from a branch**.
4. Select your publishing branch (usually `main`) and the `/(root)` folder, then save.
5. Wait for GitHub Pages to publish the site. The homepage will be `index.html`; the book page will be available at `/kdp-books.html`.

Keep `index.html` and `kdp-books.html` in the same directory so navigation works correctly.

## Before launch

- Open every Gumroad and Amazon link and confirm that it points to the correct, live listing.
- Check current prices, availability, descriptions, and book cover images.
- Test the site on a phone and desktop, and check keyboard navigation.
- Test the WhatsApp and email links.
- Add a custom domain only after configuring it in GitHub Pages.
- Add a privacy policy and any applicable terms/refund details that match the way the site actually operates.

## Notes and limitations

- This is a static HTML site. It does not include a backend, newsletter subscription service, analytics integration, or server-side form processing.
- The product finder runs in the visitor's browser and does not send or store quiz answers.
- The Amazon cover images use best-effort external loading; availability can vary. Replace them with approved, reliable image URLs if needed.
- No book titles, reviews, or product details have been invented where the original listing data was unavailable.
- No license is included. Add a license only if you intend to grant others permission to reuse or modify the code/content.
